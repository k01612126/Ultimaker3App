export class PrintJob {
  time_elapsed: number;
  time_total: number;
  source: string;
  source_user: string;
  source_application: string;
  name: string;
  time_remaining: number;
}
