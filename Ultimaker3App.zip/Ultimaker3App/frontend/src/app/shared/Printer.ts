import {Bed} from "./Bed";

export class Printer {
 status: string;
 bed: Bed;
}
