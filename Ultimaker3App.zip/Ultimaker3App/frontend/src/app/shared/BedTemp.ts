export class BedTemp {
 current: number;
 target: number;
}
