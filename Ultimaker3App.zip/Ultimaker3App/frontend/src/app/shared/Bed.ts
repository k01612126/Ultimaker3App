import {BedTemp} from "./BedTemp";

export class Bed {
 temperature: BedTemp;
}
